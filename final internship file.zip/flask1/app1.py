from flask import Flask,render_template,request
import mysql.connector
user_dict={'admin':'1234','user':'5678'}
conn = mysql.connector.connect(host='localhost',user='root',password='',database='donor')
mycursor=conn.cursor()
#create a flask application
app = Flask(__name__)

#Define the route 

@app.route('/')
def hello():
    return render_template('first.html')

@app.route('/donors')
def donors():
    return render_template('donor.html')

@app.route('/login')
def login():
    return render_template('login.html')


@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/home',methods=['POST'])
def home():
    uname=request.form['username']
    pwd=request.form['password']

    if uname not in user_dict:
        return render_template('login.html',msg='Invalid User')
    elif user_dict[uname] != pwd:
        return render_template('login.html',msg='Invalid Password')
    else:
        return render_template('home.html')

@app.route('/register', methods =['POST'])
def register():
    password=request.form['password']
    username=request.form['username']
    query="SELECT * FROM donor WHERE EMAIL = %s AND PASSWORD =%s"
    values=username,password
    mycursor.execute(query,values)
    account=mycursor.fetchall()
    if account:
        msg ='Logged in successfully'
        return render_template('department.html',msg=msg)
    else:
        msg= 'incorrect credentials'
    return render_template('contact.html',msg=msg)



@app.route('/view')
def view():
    query="SELECT * FROM donor"
    mycursor.execute(query)
    data=mycursor.fetchall()
    return render_template('view.html',sqldata=data)

@app.route('/search')
def searchpage():
    return render_template('search.html')


@app.route('/searchresult',methods=['POST'])
def search():
    city = request.form['city']
    bloodgroup = request.form['bloodgroup']
    query= "SELECT *FROM donor WHERE CITY = %s AND BLOOD_GROUP=%s"
    data=(city,bloodgroup)
    mycursor.execute(query,data)
    data=mycursor.fetchall()
    return render_template('view.html',sqldata=data)
    
@app.route('/add')
def add():
    return render_template('donor.html')

@app.route('/read',methods=['POST'])
def read():
    donorid = request.form['donorid']
    firstname = request.form['fname']
    lastname = request.form['lname']
    dob = request.form['dob']
    bloodgroup = request.form['bloodgroup']
    lastdonate = request.form['lastdonate']
    phone = request.form['phone']
    address = request.form['address']
    city= request.form['city']
    state = request.form['state']
    country = request.form['country']
    username = request.form['username']
    password = request.form['password']

    query = "INSERT INTO donor(DONOR_ID,FIRST_NAME,LAST_NAME,DOB,BLOOD_GROUP,LAST_DONATE,PHONE,ADDRESS,CITY,STATE,COUNTRY,EMAIL,PASSWORD) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    data = (donorid,firstname,lastname,dob,bloodgroup,lastdonate,phone,address,city,state,country,username,password)
    mycursor.execute(query,data)
    conn.commit()
    return render_template('donor.html',msgdata='Added Successfully')


#Run the flask app
if __name__=='__main__':
    app.run(port=5001,debug = True)